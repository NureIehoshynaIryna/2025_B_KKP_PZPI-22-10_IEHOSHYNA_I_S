﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using server.Services;
using Stripe;
using Stripe.Checkout;
using Stripe.FinancialConnections;
using System.IO;
using System.Net;
using System.Xml.Linq;

namespace server.Controllers {
    public class BooksController : BaseApiController {
        private readonly IBooksService booksService;
        private readonly IConfiguration _config;
        private readonly IAccountsService accountsService;

        public BooksController(IBooksService booksService, IConfiguration config, IAccountsService accountsService) {
            this.booksService = booksService;
            _config = config;
            this.accountsService = accountsService;
        }

        [AllowAnonymous]
        [HttpGet("api/books")]
        public async Task<IEnumerable<BookDto>> GetBooks([FromQuery] string name, [FromQuery] string author, [FromQuery] string genre, [FromQuery] int take = 20, [FromQuery] int skip = 0) {
            if (take < 1)
                throw new ArgumentException("Take is too small, 1 is a min.");
            if (take > 1000)
                throw new ArgumentException("Take is too big, 100 is a max.");

            return await booksService.GetBooks(take, skip, name, author, genre);
        }

        [AllowAnonymous]
        [HttpGet, Route("api/genres")]
        public async Task<IEnumerable<GenreDto>> GetGenres() {
            var genres = booksService.GetGenres();
            return await genres;
        }

        [HttpGet, Route("api/user/books")]
        public async Task<IEnumerable<BookDto>> GetUsersBooks([FromQuery] string name, [FromQuery] string author, [FromQuery] string genre, [FromQuery] bool? isFavourite, [FromQuery] int take = 20, [FromQuery] int skip = 0) {
            if (take < 1)
                throw new ArgumentException("Take is too small, 1 is a min.");
            if (take > 1000)
                throw new ArgumentException("Take is too big, 100 is a max.");
            var account = await accountsService.GetAccount(CurrentIdentity.UserId);

            var books = booksService.GetUsersBooks(take, skip, name, author, genre, isFavourite, CurrentIdentity.UserId, account.Id);
            return await books;
        }

        [HttpPost, Route("api/user/books/favourite/add")]
        public async Task AddBookToFavourite([FromBody] int bookId) {
            var account = await accountsService.GetAccount(CurrentIdentity.UserId);
            await booksService.AddBookToFavourite(account.Id, bookId);
        }

        [HttpPost, Route("api/user/books/favourite/remove")]
        public async Task RemoveBookFromFavourite([FromBody] int bookId) {
            var account = await accountsService.GetAccount(CurrentIdentity.UserId);
            await booksService.RemoveBookFromFavourite(account.Id, bookId);
        }

        [HttpGet, Route("api/{accountId:int}/books/favourite")]
        public async Task<IEnumerable<BookDto>> GetFavouriteBooks(int accountId, int take = 20, int skip = 0) {
            if (take < 1)
                throw new ArgumentException("Take is too small, 1 is a min.");
            if (take > 1000)
                throw new ArgumentException("Take is too big, 100 is a max.");

            var books = booksService.GetFavouriteBooks(take, skip, CurrentIdentity.UserId, CurrentIdentity.UserEmail, accountId);
            return await books;
        }

        [AllowAnonymous]
        [HttpGet, Route("api/books/{bookId:int}")]
        public async Task<BookDetailsDto> GetBookDetails(int bookId) {
            var book = await booksService.GetBookDetails(bookId);

            if (CurrentIdentity != null) {
                var account = await accountsService.GetAccount(CurrentIdentity.UserId);
                book = await booksService.GetBookStatuses(book, account.Id);
            }

            return book;
        }

        [HttpGet("api/files/{bookId:int}")]
        public async Task<IActionResult> GetBookFile(int bookId) {
            var account = await accountsService.GetAccount(CurrentIdentity.UserId);
            var filePath = await booksService.GetBookFilePath(bookId, account.Id, CurrentIdentity.UserEmail);

            if (string.IsNullOrWhiteSpace(filePath) || !System.IO.File.Exists(filePath)) {
                return NotFound("File is not found.");
            }

            var provider = new Microsoft.AspNetCore.StaticFiles.FileExtensionContentTypeProvider();
            if (!provider.TryGetContentType(filePath, out var contentType)) {
                contentType = "application/octet-stream";
            }

            var fileName = Path.GetFileName(filePath);
            return PhysicalFile(filePath, contentType, fileName);
        }

        [HttpPost("api/admin/uploadbook")]
        public async Task<IActionResult> UploadBook(IFormFile file) {
            if (file == null || file.Length == 0)
                return BadRequest("No file provided");

            var fileExtension = Path.GetExtension(file.FileName);
            if(fileExtension != ".fb2") {
                return BadRequest("File is not fb2 format");
            }

            using (var stream = file.OpenReadStream()) {
                var newbookId = await booksService.UploadBook(stream);

                return Ok(new { bookId = newbookId, message = "File uploaded successfully." });
            }
        }

        [AllowAnonymous]
        [HttpGet("api/files/{bookId:int}/cover")]
        public async Task<IActionResult> GetBookCover(int bookId) {
            var filePath = await booksService.GetBookCover(bookId);

            if (string.IsNullOrWhiteSpace(filePath) || !System.IO.File.Exists(filePath)) {
                return NotFound("File is not found.");
            }

            var provider = new Microsoft.AspNetCore.StaticFiles.FileExtensionContentTypeProvider();
            if (!provider.TryGetContentType(filePath, out var contentType)) {
                contentType = "image/png";
            }

            var fileName = Path.GetFileName(filePath);
            return PhysicalFile(filePath, contentType, fileName);
        }


        [HttpPost, Route("api/{accountId:int}/books/{bookId:int}/rating")]
        public async Task SetRating(int bookId, int accountId, decimal rating) {
            await booksService.SetRating(bookId, accountId, rating, CurrentIdentity.UserEmail);
        }

        [HttpPost, Route("api/payments/checkout-session")]
        public async Task<ActionResult<object>> CreateCheckoutSession([FromQuery] int bookId, [FromBody] CheckoutRequestDto request) {
            var account = await accountsService.GetAccount(CurrentIdentity.UserId);
            var book = await booksService.GetBookDetails(bookId);
            book = await booksService.GetBookStatuses(book, account.Id);

            if (book.price == 0) {
                await booksService.AddBookToAccount(bookId, account.Id, CurrentIdentity.UserEmail);
                return Ok(new { url = "" });
            }

            if (book.isBought) {
                return Ok(new { url = "" });
            }

            request.UnitAmount = book.price * 100;

            var options = new Stripe.Checkout.SessionCreateOptions {
                PaymentMethodTypes = new List<string> { "card" },
                LineItems = new List<SessionLineItemOptions> {
                new SessionLineItemOptions {
                    PriceData = new SessionLineItemPriceDataOptions {
                        UnitAmount = request.UnitAmount,
                        Currency = request.Currency,
                        ProductData = new SessionLineItemPriceDataProductDataOptions {
                            Name = request.ProductName,
                        },
                    },
                    Quantity = request.Quantity,
                },
            },
                Mode = "payment",
                SuccessUrl = request.SuccessUrl,
                CancelUrl = request.CancelUrl,

                Metadata = new Dictionary<string, string> {
                    { "account_id", account.Id.ToString() },
                    { "book_id", bookId.ToString() },
                    { "email", CurrentIdentity.UserEmail }
                }
            };

            var service = new Stripe.Checkout.SessionService();
            var session = await service.CreateAsync(options);

            return Ok(new { id = session.Id, url = session.Url });
        }

        [AllowAnonymous]
        [HttpPost, Route("api/payments/webhook")]
        public async Task<IActionResult> StripeWebhook() {
            var json = await new StreamReader(HttpContext.Request.Body).ReadToEndAsync();

            try {
                var stripeEvent = EventUtility.ConstructEvent(
                    json,
                    Request.Headers["Stripe-Signature"],
                    _config["Stripe:WebhookSecret"]
                );

                if (stripeEvent.Type == "checkout.session.completed") {
                    var session = stripeEvent.Data.Object as Stripe.Checkout.Session;
                    if (session != null) {
                        var accountId = int.Parse(session.Metadata["account_id"]);
                        var bookId = int.Parse(session.Metadata["book_id"]);
                        var email = session.Metadata["email"];

                        await booksService.AddBookToAccount(bookId, accountId, email);
                    }
                }

                return Ok();
            }
            catch (StripeException e) {
                return BadRequest();
            }
        }
    }
}
