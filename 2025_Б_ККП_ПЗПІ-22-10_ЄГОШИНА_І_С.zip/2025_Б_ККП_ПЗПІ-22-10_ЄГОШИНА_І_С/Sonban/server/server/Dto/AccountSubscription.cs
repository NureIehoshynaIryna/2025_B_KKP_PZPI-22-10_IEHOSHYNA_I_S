﻿namespace server {
    public enum AccountSubscription {
        Free = 1,
        Standart = 2,
        Enterprise = 3,
        Family = 4,
    }
}
