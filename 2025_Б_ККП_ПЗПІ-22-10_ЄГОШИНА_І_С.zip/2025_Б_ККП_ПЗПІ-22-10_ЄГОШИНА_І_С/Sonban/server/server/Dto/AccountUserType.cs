﻿namespace server {
    public enum AccountUserType {
        NoAccess = 0,
        Member = 1,
        Admin = 2,
    }
}
