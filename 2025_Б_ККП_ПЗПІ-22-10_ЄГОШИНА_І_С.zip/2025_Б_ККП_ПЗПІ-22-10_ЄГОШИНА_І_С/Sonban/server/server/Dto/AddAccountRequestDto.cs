﻿namespace server;

public class AddAccountRequestDto {
    public string Name { get; set; }
}