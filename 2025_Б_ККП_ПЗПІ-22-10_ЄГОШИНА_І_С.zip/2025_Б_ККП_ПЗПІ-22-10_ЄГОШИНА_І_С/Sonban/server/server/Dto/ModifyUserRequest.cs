﻿namespace server;

public class ModifyUserRequest {
    public string Name { get; set; }
}