﻿namespace server;

public class RemoveAccountUserRequest {
    public string Email { get; set; }
}