﻿namespace server;

public class SubscriptionRequest {
    public string Name { get; set; }
    public decimal Price { get; set; }
}