using Microsoft.Extensions.DependencyInjection;
using server.Classes;
using server.Repository;
using server.Services;
using System.Text.Json.Serialization;

namespace server
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            ConfigureServices(builder.Services, builder.Configuration);

            var app = builder.Build();

            Stripe.StripeConfiguration.ApiKey = builder.Configuration["Stripe:SecretKey"];

            app.UseCors(policy => {
                policy
                    .AllowAnyHeader()
                    .AllowAnyMethod()
                    .AllowAnyOrigin()
                    //.AllowCredentials()
                    //.WithOrigins(allowedHosts)
                    ;
            });

            app.UseMiddleware<ErrorHandlingMiddleware>();

            if (app.Environment.IsDevelopment()) {
                app.UseSwagger();
                app.UseSwaggerUI(c => {
                    c.DefaultModelsExpandDepth(-1);
                    // c.SwaggerEndpoint("/swagger/v1/swagger.json", "V1");
                });
            }
            else {
                app.UseHttpsRedirection();
            }

            app.UseAuthorization();

            app.UseStaticFiles();
            app.MapControllers();

            app.Run();
        }

        private static void ConfigureServices(IServiceCollection services, IConfiguration configuration) {

            services.AddSingleton<ISettingsProvider>(provider => new SettingsProvider(configuration));

            services.AddSingleton<IUsersService>(provider => new UsersService(
                provider.GetService<IUsersRepository>()
            ));
            services.AddSingleton<IUsersRepository>(provider => new UsersRepository(
                provider.GetService<ISettingsProvider>()
            ));

            services.AddSingleton<IAccountsRepository>(provider => new AccountsRepository(
                provider.GetService<ISettingsProvider>()
            ));
            services.AddSingleton<IAccountsService>(provider => new AccountsService(
                provider.GetService<IAccountsRepository>()
            ));


            services.AddSingleton<IBooksRepository>(provider => new BooksRepository(
                provider.GetService<ISettingsProvider>()
            ));
            services.AddSingleton<IBooksService>(provider => new BooksService(
                provider.GetService<IBooksRepository>(), 
                provider.GetService<IAccountsRepository>(),
                provider.GetService<ISettingsProvider>()
            ));

            //services.AddSingleton<ISystemAdminService>(provider => new SystemAdminService(
            //    provider.GetService<ISystemAdminRepository>()
            //));
            //services.AddSingleton<ISystemAdminRepository>(provider => new SystemAdminRepository(
            //    provider.GetService<ISettingsProvider>()
            //));

            services.AddControllers(config => {
                config.Filters.Add(typeof(AuthCookieCheckFilterAttribute));
            }).AddJsonOptions(x => {
                x.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
            });

            services.AddEndpointsApiExplorer();
            services.AddSwaggerGen();
        }

    }
}
