<template>
  <div class="book-details" v-if="bookDetails">
    <div class="book-header">
      <img :src="`/api/files/${bookDetails.id}/cover`" alt="Cover" class="cover" />

      <div class="info">
        <h1 class="title">{{ bookDetails.name }}</h1>

        <p><strong>Author(s):</strong>
          {{bookDetails.authors.map(a => a.name).join(', ') || 'Unknown'}}</p>
        <p><strong>Genre(s):</strong>
          {{bookDetails.genres.map(g => g.name).join(', ') || 'Uncategorized'}}</p>
        <p><strong>Year:</strong> {{ bookDetails.createdYear || 'Unknown' }}</p>
        <p><strong>Rating:</strong> {{ bookDetails.rating.toFixed(1) }} out of 5</p>
        <p><strong>Price:</strong>
          {{ bookDetails.price === 0 ? 'Free' : `$${bookDetails.price}` }}</p>

        <div class="button-actions">
          <button v-if="bookDetails.isBought" class="btn download" @click="handleDownload()">
            📥 Download</button>
          <button v-else-if="bookDetails.price === 0" class="btn buy" @click="buyBook">
            📚 Add to library
          </button>
          <button v-else class="btn buy" @click="buyBook">🛒 Buy</button>
          <button class="btn" @click="toggleFavourite">
            {{ bookDetails.isFavourite ? '🗑 Remove from favourite' : '❤ Add to favourite' }}
          </button>
        </div>
      </div>
    </div>

    <div class="description">
      <h2>Anotation</h2>
      <p>{{ bookDetails.description }}</p>
    </div>

    <router-link class="back-link" to="/">← Back to library</router-link>
  </div>

  <div v-else class="loading_message">
    <p>Loading...</p>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex';

export default {
  computed: {
    ...mapState(['bookDetails']),
  },

  methods: {
    ...mapActions(['fetchBookDetails', 'addToFavourites', 'removeFromFavourites', 'buyBookSession', 'downloadBook']),

    async toggleFavourite() {
      try {
        if (this.bookDetails.isFavourite) {
          await this.removeFromFavourites(this.bookDetails.id);
          this.bookDetails.isFavourite = false;
        } else {
          await this.addToFavourites(this.bookDetails.id);
          this.bookDetails.isFavourite = true;
        }
      } catch (err) {
        alert(err);
      }
    },

    async buyBook() {
      const request = {
        productName: this.bookDetails.name,
        unitAmount: Math.round(this.bookDetails.price * 100), // в копійки
        quantity: 1,
        currency: 'usd',
        successUrl: `${window.location.origin}/book/${this.bookDetails.id}`,
        cancelUrl: `${window.location.origin}/book/${this.bookDetails.id}`,
      };
      this.buyBookSession({ bookId: this.bookDetails.id, request });
    },

    async handleDownload() {
      this.downloadBook({ bookId: this.bookDetails.id, title: this.bookDetails.name });
    },
  },
  watch: {
    '$route.params.id': {
      immediate: true,
      handler(newId) {
        if (newId) {
          this.fetchBookDetails(newId);
        }
      },
    },
  },
};
</script>

<style scoped>
.book-details {
  max-width: 900px;
  margin: 0 auto;
  padding: 30px;
  font-family: Arial, sans-serif;
}

.book-header {
  display: flex;
  gap: 30px;
  align-items: flex-start;
  margin-bottom: 30px;
}

.cover {
  width: 200px;
  height: auto;
  border-radius: 12px;
  object-fit: cover;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.info {
  flex: 1;
}

.info p{
  margin-top: 10px;
}

.title {
  font-size: 2rem;
  margin-bottom: 10px;
}

.button-actions {
  display: flex;
  align-items: center;
  gap: 15px;
  margin-top: 15px;
}

.btn {
  padding: 8px 16px;
  background-color: #d4d4d4;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: 0.2s;
}

.btn:hover {
  background-color: #9e9e9e;
}

.buy {
  background-color: #4caf50;
  color: white;
}

.buy:hover {
  background-color: #429344;
}

.description {
  margin-top: 20px;
}

.description h2 {
  font-size: 1.5rem;
  margin-bottom: 10px;
}

.back-link {
  display: inline-block;
  margin-top: 20px;
  text-decoration: underline;
  color: #007bff;
}

.loading_message {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 75vh;
}

.loading_message p {
  font-size: 1.5rem;
  font-weight: bold;
}
</style>
