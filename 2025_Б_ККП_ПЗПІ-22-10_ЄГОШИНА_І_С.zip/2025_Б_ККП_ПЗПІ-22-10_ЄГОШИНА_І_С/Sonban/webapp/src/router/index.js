import {
  createRouter,
  createWebHistory,
} from 'vue-router';
import MainPage from '@/pages/MainPage.vue';
import LoginPage from '@/pages/LoginPage.vue';
import RegisterPage from '@/pages/RegisterPage.vue';
import ProfilePage from '@/pages/ProfilePage.vue';
import UserLibraryPage from '@/pages/UserLibraryPage.vue';
import BookPage from '@/pages/BookPage.vue';
import UploadBookPage from '@/pages/UploadBookPage.vue';

export default createRouter({
  history: createWebHistory(),
  routes: [{
    path: '/',
    name: 'MainPage',
    components: {
      default: MainPage,
    },
  },
  {
    path: '/login',
    name: 'LoginPage',
    props: true,
    component: LoginPage,
  },
  {
    path: '/register',
    name: 'RegisterPage',
    props: true,
    component: RegisterPage,
  },
  {
    path: '/profile',
    name: 'ProfilePage',
    props: true,
    component: ProfilePage,
  },
  {
    path: '/userLibrary',
    name: 'UserLibrary',
    props: true,
    component: UserLibraryPage,
  },
  {
    path: '/book/:id',
    name: 'BookDetails',
    props: true,
    component: BookPage,
  },
  {
    path: '/admin/uploadbook',
    name: 'UploadBook',
    props: true,
    component: UploadBookPage,
  },
  ],
});
