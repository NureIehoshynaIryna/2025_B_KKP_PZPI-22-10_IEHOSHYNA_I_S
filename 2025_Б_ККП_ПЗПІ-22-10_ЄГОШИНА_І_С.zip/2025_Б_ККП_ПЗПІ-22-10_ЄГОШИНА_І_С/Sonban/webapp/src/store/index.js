import { createStore } from 'vuex';
import axios from 'axios';

export default createStore({
  state: {
    user: null,
    books: [],
    bookDetails: null,
    genres: [],
    userLibrary: [],
  },
  mutations: {
    updateUserInfo(state, user) {
      state.user = user;
    },
    updateBooks(state, books) {
      state.books = books;
    },
    SET_BOOK_DETAILS(state, details) {
      state.bookDetails = details;
    },
    updateGenres(state, genres) {
      state.genres = genres;
    },
    updateUserLibrary(state, library) {
      state.userLibrary = library;
    },
  },
  actions: {
    // USER
    async postUserInfo({ commit }, { email, password }) {
      try {
        const response = await axios.post('api/profile/login', {
          email,
          password,
        });
        commit('updateUserInfo', response.data);
      } catch (error) {
        console.error('Login error:', error);
        if (error.response?.status === 403) {
          alert('Невірна пошта або пароль');
        }
      }
    },

    async postRegisterUser({ commit }, { name, email, password }) {
      try {
        const response = await axios.post('/api/profile/register', {
          name,
          email,
          password,
        });
        commit('updateUserInfo', response.data);
      } catch (error) {
        console.error('Register error:', error);
      }
    },

    async logout({ commit }) {
      try {
        await axios.get('/api/profile/logout');
        commit('updateUserInfo', null);
      } catch (error) {
        console.error('Logout error:', error);
      }
    },

    async fetchUserInfo({ commit }) {
      try {
        const response = await axios.get('/api/profile');
        commit('updateUserInfo', response.data);
      } catch (error) {
        console.warn('User is not authorised');
      }
    },

    async updateProfile({ commit }, userInfo) {
      try {
        const response = await axios.post('/api/profile', userInfo);
        commit('updateUserInfo', response.data);
        return true;
      } catch (error) {
        console.error('Error updating profile:', error);
        return false;
      }
    },

    // BOOKS
    async fetchBooks(
      { commit },
      {
        take = 20, page = 1, name = null, author = null, genre = null,
      },
    ) {
      const skip = (page - 1) * take;
      const res = await axios.get('/api/books', {
        params: {
          take, skip, name, author, genre,
        },
      });
      commit('updateBooks', res.data);
    },

    async fetchGenres({ commit }) {
      const res = await axios.get('/api/genres');
      commit('updateGenres', res.data);
    },

    async fetchBookDetails({ commit }, bookId) {
      const res = await axios.get(`/api/books/${bookId}`);
      commit('SET_BOOK_DETAILS', res.data);
    },

    // USERS BOOKS
    async fetchUserLibrary(
      { commit },
      {
        take = 20, page = 1, name = null, author = null, genre = null, isFavourite = null,
      },
    ) {
      const skip = (page - 1) * take;
      const res = await axios.get('api/user/books', {
        params: {
          take, skip, name, author, genre, isFavourite,
        },
      });
      commit('updateUserLibrary', res.data);
    },

    async addToFavourites(_, bookId) {
      try {
        await axios.post('/api/user/books/favourite/add', bookId, {
          headers: { 'Content-Type': 'application/json' },
        });
      } catch (err) {
        if (err.response?.status === 401) {
          alert('⚠️ Увійдіть в акаунт для додавання до обраного.');
        } else {
          console.error(err);
          alert('⚠️ Не вдалося додати до обраного.');
        }
      }
    },

    async removeFromFavourites(_, bookId) {
      try {
        console.log(bookId);
        await axios.post('/api/user/books/favourite/remove', bookId, {
          headers: { 'Content-Type': 'application/json' },
        });
      } catch (err) {
        console.error(err);
        alert('⚠️ Не вдалося видалити з обраного.');
        throw err;
      }
    },

    async buyBookSession(_, { bookId, request }) {
      try {
        const res = await axios.post(`/api/payments/checkout-session?bookId=${bookId}`, request);
        const sessionUrl = res.data.url;
        if (sessionUrl && sessionUrl.trim() !== '') {
          window.location.href = sessionUrl;
        } else {
          window.location.href = `/book/${bookId}`;
        }
      } catch (err) {
        if (err.response?.status === 401) {
          alert('⚠️ Увійдіть в акаунт для покупки книги.');
        } else {
          console.error(err);
          alert('⚠️ Помилка під час створення сесії Stripe.');
        }
      }
    },

    async downloadBook(_, { bookId, title }) {
      try {
        const response = await axios.get(`/api/files/${bookId}`, {
          responseType: 'blob',
        });

        const blob = new Blob([response.data], { type: response.headers['content-type'] });
        const url = window.URL.createObjectURL(blob);

        const link = document.createElement('a');
        link.href = url;

        link.download = `${title}.fb2`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
      } catch (error) {
        console.error(error);
        alert(error);
      }
    },
    async uploadBookFile(_, file) {
      const formData = new FormData();
      formData.append('file', file);

      try {
        const response = await axios.post('/api/admin/uploadbook', formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });
        // const response = await axios.post('/api/admin/uploadbook', formData);
        alert('Книгу успішно завантажено!');
        console.log(response.data);
      } catch (error) {
        // console.error(error);
        alert(error);
      }
    },
  },
  getters: {
    isAuthenticated: (state) => !!state.user,
  },
});
